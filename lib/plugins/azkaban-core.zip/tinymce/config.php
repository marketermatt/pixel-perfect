<?php
/*-----------------------------------------------------------------------------------*/
/*	Default Options
/*-----------------------------------------------------------------------------------*/

// Number of posts array
function azkaban_shortcodes_range ( $range, $all = true, $default = false, $range_start = 1 ) {
	if( $all ) {
		$number_of_posts['-1'] = 'All';
	}

	if( $default ) {
		$number_of_posts[''] = 'Default';
	}

	foreach( range( $range_start, $range ) as $number ) {
		$number_of_posts[$number] = $number;
	}

	return $number_of_posts;
}

// Taxonomies
function azkaban_shortcodes_categories ( $taxonomy, $empty_choice = false ) {
	if( $empty_choice == true ) {
		$post_categories[''] = 'Default';
	}

	$get_categories = get_categories('hide_empty=0&taxonomy=' . $taxonomy);

	if( ! array_key_exists('errors', $get_categories) ) {
		if( $get_categories && is_array($get_categories) ) {
			foreach ( $get_categories as $cat ) {
				$post_categories[$cat->slug] = $cat->name;
			}
		}

		if( isset( $post_categories ) ) {
			return $post_categories;
		}
	}
}

$choices = array( 'yes' => 'Yes', 'no' => 'No' );
$reverse_choices = array( 'no' => 'No', 'yes' => 'Yes' );
$choices_with_default = array( '' => 'Default', 'yes' => 'Yes', 'no' => 'No' );
$reverse_choices_with_default = array( '' => 'Default', 'no' => 'No', 'yes' => 'Yes' );
$leftright = array( 'left' => 'Left', 'right' => 'Right' );
$dec_numbers = array( '0.1' => '0.1', '0.2' => '0.2', '0.3' => '0.3', '0.4' => '0.4', '0.5' => '0.5', '0.6' => '0.6', '0.7' => '0.7', '0.8' => '0.8', '0.9' => '0.9', '1' => '1' );

// Fontawesome icons list
$pattern = '/\.(fa-(?:\w+(?:-)?)+):before\s+{\s*content:\s*"(.+)";\s+}/';
$fontawesome_path = AX_TINYMCE_DIR . '/css/font-awesome.css';
if( file_exists( $fontawesome_path ) ) {
	@$subject = file_get_contents( $fontawesome_path );
}

preg_match_all($pattern, $subject, $matches, PREG_SET_ORDER);

$icons = array();

foreach($matches as $match){
	$icons[$match[1]] = $match[2];
}

$checklist_icons = array ( 'icon-check' => '\f00c', 'icon-star' => '\f006', 'icon-angle-right' => '\f105', 'icon-asterisk' => '\f069', 'icon-remove' => '\f00d', 'icon-plus' => '\f067' );

/*-----------------------------------------------------------------------------------*/
/*	Shortcode Selection Config
/*-----------------------------------------------------------------------------------*/

$azkaban_shortcodes['shortcode-generator'] = array(
	'no_preview' => true,
	'params' => array(),
	'shortcode' => '',
	'popup_title' => ''
);

/*-----------------------------------------------------------------------------------*/
/*	Alert Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['alert'] = array(
	'no_preview' => true,
	'params' => array(

		'type' => array(
			'type' => 'select',
			'label' => __( 'Alert Type', 'azkaban-core' ),
			'desc' => __( 'Select the type of alert message. Choose custom for advanced color options below.', 'azkaban-core' ),
			'options' => array(
				'general' => 'General',
				'error' => 'Error',
				'success' => 'Success',
				'notice' => 'Notice',
				'custom' => 'Custom',
			)
		),
		'accentcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Accent Color', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. Set the border, text and icon color for custom alert boxes.', 'azkaban-core')
		),
		'backgroundcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Background Color', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. Set the background color for custom alert boxes.', 'azkaban-core')
		),
		'bordersize' => array(
			'std' => '1px',
			'type' => 'text',
			'label' => __( 'Border Width', 'azkaban-core' ),
			'desc' => 'Custom setting only. For custom alert boxes. In pixels (px), ex: 1px.'
		),
		'icon' => array(
			'type' => 'iconpicker',
			'label' => __( 'Select Custom Icon', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. Click an icon to select, click again to deselect', 'azkaban-core' ),
			'options' => $icons
		),
		'boxshadow' => array(
			'type' => 'select',
			'label' => __( 'Box Shadow', 'azkaban-core' ),
			'desc' =>  __( 'Display a box shadow below the alert box.', 'azkaban-core' ),
			'options' => $choices
		),		
		'content' => array(
			'std' => 'Your Content Goes Here',
			'type' => 'textarea',
			'label' => __( 'Alert Content', 'azkaban-core' ),
			'desc' => __( 'Insert the alert\'s content', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),		
	),
	'shortcode' => '[alert type="{{type}}" accent_color="{{accentcolor}}" background_color="{{backgroundcolor}}" border_size="{{bordersize}}" icon="{{icon}}" box_shadow="{{boxshadow}}" class="{{class}}" id="{{id}}"]{{content}}[/alert]',
	'popup_title' => __( 'Alert Shortcode', 'azkaban-core' )
);


/*-----------------------------------------------------------------------------------*/
/*	Blog Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['blog'] = array(
	'no_preview' => true,
	'params' => array(

		'layout' => array(
			'type' => 'select',
			'label' => __( 'Blog Layout', 'azkaban-core' ),
			'desc' => __( 'Select the layout for the blog shortcode', 'azkaban-core' ),
			'options' => array(
				'large' => 'Large',
				'medium' => 'Medium',
				'large alternate' => 'Large Alternate',
				'medium alternate' => 'Medium Alternate',
				'grid' => 'Grid',
				'timeline' => 'Timeline'
			)
		),
		'posts_per_page' => array(
			'type' => 'select',
			'label' => __( 'Posts Per Page', 'azkaban-core' ),
			'desc' => __( 'Select number of posts per page', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 25, true, true )
		),
		'cat_slug' => array(
			'type' => 'multiple_select',
			'label' => __( 'Categories', 'azkaban-core' ),
			'desc' => __( 'Select a category or leave blank for all', 'azkaban-core' ),
			'options' => azkaban_shortcodes_categories( 'category' )
		),
		'exclude_cats' => array(
			'type' => 'multiple_select',
			'label' => __( 'Exclude Categories', 'azkaban-core' ),
			'desc' => __( 'Select a category to exclude', 'azkaban-core' ),
			'options' => azkaban_shortcodes_categories( 'category' )
		),
		'title' => array(
			'type' => 'select',
			'label' => __( 'Show Title', 'azkaban-core' ),
			'desc' =>  __( 'Display the post title below the featured image', 'azkaban-core' ),
			'options' => $choices
		),
		'title_link' => array(
			'type' => 'select',
			'label' => __( 'Link Title To Post', 'azkaban-core' ),
			'desc' =>  __( 'Choose if the title should be a link to the single post page.', 'azkaban-core' ),
			'options' => $choices
		),		
		'thumbnail' => array(
			'type' => 'select',
			'label' => __( 'Show Thumbnail', 'azkaban-core' ),
			'desc' =>  __( 'Display the post featured image', 'azkaban-core' ),
			'options' => $choices
		),
		'excerpt' => array(
			'type' => 'select',
			'label' => __( 'Show Excerpt', 'azkaban-core' ),
			'desc' =>  __( 'Show excerpt or choose "no" for full content', 'azkaban-core' ),
			'options' => $choices
		),
		'excerpt_length' => array(
			'std' => 35,
			'type' => 'select',
			'label' => __( 'Number of words/characters in Excerpt', 'azkaban-core' ),
			'desc' =>  __( 'Controls the excerpt length based on words or characters that is set in Theme Options > Extra.', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 60, false )
		),
		'meta_all' => array(
			'type' => 'select',
			'label' => __( 'Show Meta Info', 'azkaban-core' ),
			'desc' =>  __( 'Choose to show all meta data', 'azkaban-core' ),
			'options' => $choices
		),
		'meta_author' => array(
			'type' => 'select',
			'label' => __( 'Show Author Name', 'azkaban-core' ),
			'desc' =>  __( 'Choose to show the author', 'azkaban-core' ),
			'options' => $choices
		),
		'meta_categories' => array(
			'type' => 'select',
			'label' => __( 'Show Categories', 'azkaban-core' ),
			'desc' =>  __( 'Choose to show the categories', 'azkaban-core' ),
			'options' => $choices
		),
		'meta_comments' => array(
			'type' => 'select',
			'label' => __( 'Show Comment Count', 'azkaban-core' ),
			'desc' =>  __( 'Choose to show the comments', 'azkaban-core' ),
			'options' => $choices
		),
		'meta_date' => array(
			'type' => 'select',
			'label' => __( 'Show Date', 'azkaban-core' ),
			'desc' =>  __( 'Choose to show the date', 'azkaban-core' ),
			'options' => $choices
		),
		'meta_link' => array(
			'type' => 'select',
			'label' => __( 'Show Read More Link', 'azkaban-core' ),
			'desc' =>  __( 'Choose to show the link', 'azkaban-core' ),
			'options' => $choices
		),
		'meta_tags' => array(
			'type' => 'select',
			'label' => __( 'Show Tags', 'azkaban-core' ),
			'desc' =>  __( 'Choose to show the tags', 'azkaban-core' ),
			'options' => $choices
		),
		'paging' => array(
			'type' => 'select',
			'label' => __( 'Show Pagination', 'azkaban-core' ),
			'desc' =>  __( 'Show numerical pagination boxes', 'azkaban-core' ),
			'options' => $choices
		),
		'scrolling' => array(
			'type' => 'select',
			'label' => __( 'Infinite Scrolling', 'azkaban-core' ),
			'desc' =>  __( 'Choose the type of scrolling', 'azkaban-core' ),
			'options' => array(
				'pagination' => 'Pagination',
				'infinite' => 'Infinite Scrolling'
			)
		),
		'blog_grid_columns' => array(
			'type' => 'select',
			'label' => __( 'Grid Layout # of Columns', 'azkaban-core' ),
			'desc' => __( 'Select whether to display the grid layout in 2, 3 or 4 column.', 'azkaban-core' ),
			'options' => array(
				'2' => '2',
				'3' => '3',
				'4' => '4',
			)
		),
		'strip_html' => array(
			'type' => 'select',
			'label' => __( 'Strip HTML from Posts Content', 'azkaban-core' ),
			'desc' =>  __( 'Strip HTML from the post excerpt', 'azkaban-core' ),
			'options' => $choices
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),		
	),
	'shortcode' => '[blog number_posts="{{posts_per_page}}" cat_slug="{{cat_slug}}" exclude_cats="{{exclude_cats}}" title="{{title}}" title_link="{{title_link}}" thumbnail="{{thumbnail}}" excerpt="{{excerpt}}" excerpt_length="{{excerpt_length}}" meta_all="{{meta_all}}" meta_author="{{meta_author}}" meta_categories="{{meta_categories}}" meta_comments="{{meta_comments}}" meta_date="{{meta_date}}" meta_link="{{meta_link}}" meta_tags="{{meta_tags}}" paging="{{paging}}" scrolling="{{scrolling}}" strip_html="{{strip_html}}" blog_grid_columns="{{blog_grid_columns}}" layout="{{layout}}" class="{{class}}" id="{{id}}"][/blog]',
	'popup_title' => __( 'Blog Shortcode', 'azkaban-core')
);

/*-----------------------------------------------------------------------------------*/
/*	Button Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['button'] = array(
	'no_preview' => true,
	'params' => array(

		'url' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Button URL', 'azkaban-core' ),
			'desc' => __( 'Add the button\'s url ex: http://example.com.', 'azkaban-core' )
		),
		'style' => array(
			'type' => 'select',
			'label' => __( 'Button Style', 'azkaban-core' ),
			'desc' => __( 'Select the button\'s color. Select default or color name for theme options, or select custom to use advanced color options below.', 'azkaban-core' ),
			'options' => array(
				'default' => 'Default',
				'custom' => 'Custom',
				'green' => 'Green',
				'darkgreen' => 'Dark Green',
				'orange' => 'Orange',
				'blue' => 'Blue',
				'red' => 'Red',
				'pink' => 'Pink',
				'darkgray' => 'Dark Gray',
				'lightgray' => 'Light Gray',
			)
		),
		'size' => array(
			'type' => 'select',
			'label' => __( 'Button Size', 'azkaban-core' ),
			'desc' => __( 'Select the button\'s size. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => array(
				'' => 'Default',
				'small' => 'Small',
				'medium' => 'Medium',
				'large' => 'Large',
				'xlarge' => 'XLarge',
			)
		),
		'type' => array(
			'type' => 'select',
			'label' => __( 'Button Type', 'azkaban-core' ),
			'desc' => __( 'Select the button\'s type. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => array(
				'' => 'Default',
				'flat' => 'Flat',
				'3d' => '3D',
			)
		),
		'shape' => array(
			'type' => 'select',
			'label' => __( 'Button Shape', 'azkaban-core' ),
			'desc' => __( 'Select the button\'s shape. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => array(
				'' => 'Default',
				'square' => 'Square',
				'pill' => 'Pill',
				'round' => 'Round',
			)
		),				
		'target' => array(
			'type' => 'select',
			'label' => __( 'Button Target', 'azkaban-core' ),
			'desc' => __( '_self = open in same window <br />_blank = open in new window.', 'azkaban-core' ),
			'options' => array(
				'_self' => '_self',
				'_blank' => '_blank'
			)
		),
		'title' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Button Title Attribute', 'azkaban-core' ),
			'desc' => __( 'Set a title attribute for the button link.', 'azkaban-core' ),
		),
		'content' => array(
			'std' => 'Button Text',
			'type' => 'text',
			'label' => __( 'Button\'s Text', 'azkaban-core' ),
			'desc' => __( 'Add the text that will display in the button.', 'azkaban-core' ),
		),
		'gradtopcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Button Gradient Top Color', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. Set the top color of the button background.', 'azkaban-core' )
		),
		'gradbottomcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Button Gradient Bottom Color', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. Set the bottom color of the button background or leave empty for solid color.', 'azkaban-core' )
		),
		'gradtopcolorhover' => array(
			'type' => 'colorpicker',
			'label' => __( 'Button Gradient Top Color Hover', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. Set the top hover color of the button background.', 'azkaban-core' )
		),
		'gradbottomcolorhover' => array(
			'type' => 'colorpicker',
			'label' => __( 'Button Gradient Bottom Color Hover', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. Set the bottom hover color of the button background or leave empty for solid color.', 'azkaban-core' )
		),
		'accentcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Accent Color', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. This option controls the color of the button border, divider, text and icon.', 'azkaban-core' )
		),
		'accenthovercolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Accent Hover Color', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. This option controls the hover color of the button border, divider, text and icon.', 'azkaban-core' )
		),		
		'bevelcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Bevel Color (3D Mode only)', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. Set the bevel color of 3D buttons.', 'azkaban-core' )
		),		
		'borderwidth' => array(
			'std' => '1px',
			'type' => 'text',
			'label' => __( 'Border Width', 'azkaban-core' ),
			'desc' => __( 'Custom setting only. In pixels (px), ex: 1px.  Leave blank for theme option selection.', 'azkaban-core' )
		),
		'shadow' => array(
			'type' => 'select',
			'label' => __( 'Shadow', 'azkaban-core' ),
			'desc' => __( 'Choose to enable/disable the shadows. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => array(
				'' => 'Default',
				'yes' => 'Yes',
				'no' => 'No',
			),
		),
		'icon' => array(
			'type' => 'iconpicker',
			'label' => __( 'Select Custom Icon', 'azkaban-core' ),
			'desc' => __( 'Click an icon to select, click again to deselect', 'azkaban-core' ),
			'options' => $icons
		),
		'iconposition' => array(
			'type' => 'select',
			'label' => __( 'Icon Position', 'azkaban-core' ),
			'desc' => __( 'Choose the position of the icon on the button.', 'azkaban-core' ),
			'options' => $leftright
		),			
		'icondivider' => array(
			'type' => 'select',
			'label' => __( 'Icon Divider', 'azkaban-core' ),
			'desc' => __( 'Choose to display a divider between icon and text.', 'azkaban-core' ),
			'options' => $choices
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),			
	),
	'shortcode' => '[button link="{{url}}" color="{{style}}" size="{{size}}" type="{{type}}" shape="{{shape}}" target="{{target}}" title="{{title}}" gradient_colors="{{gradtopcolor}}|{{gradbottomcolor}}" gradient_hover_colors="{{gradtopcolorhover}}|{{gradbottomcolorhover}}" accent_color="{{accentcolor}}" accent_hover_color="{{accenthovercolor}}" bevel_color="{{bevelcolor}}" border_width="{{borderwidth}}" shadow="{{shadow}}" icon="{{icon}}" icon_divider="{{icondivider}}" icon_position="{{iconposition}}" class="{{class}}" id="{{id}}"]{{content}}[/button]',
	'popup_title' => __( 'Button Shortcode', 'azkaban-core')
);

/*-----------------------------------------------------------------------------------*/
/*	Checklist Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['checklist'] = array(
	'params' => array(

		'icon' => array(
			'type' => 'iconpicker',
			'label' => __( 'Select Icon', 'azkaban-core' ),
			'desc' => __( 'Global setting for all list items, this can be overridden individually below. Click an icon to select, click again to deselect.', 'azkaban-core' ),
			'options' => $icons
		),
		'circle' => array(
			'type' => 'select',
			'label' => __( 'Icon in Circle', 'azkaban-core' ),
			'desc' => __( 'Global setting for all list items, this can be overridden individually below. Choose to display the icon in a circle.', 'azkaban-core' ),
			'options' => $choices
		),	
		'size' => array(
			'type' => 'select',
			'label' => __( 'Item Size', 'azkaban-core' ),
			'desc' => __( 'Select the list item\'s size.', 'azkaban-core' ),
			'options' => array(
				'small' => 'Small',
				'medium' => 'Medium',
				'large' => 'Large',
			)
		),		
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),		
	),

	'shortcode' => '[checklist icon="{{icon}}" circle="{{circle}}" size="{{size}}" class="{{class}}" id="{{id}}"]{{child_shortcode}}[/checklist]',
	'popup_title' => __( 'Checklist Shortcode', 'azkaban-core' ),
	'no_preview' => true,

	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'icon' => array(
				'type' => 'iconpicker',
				'label' => __( 'Select Icon', 'azkaban-core' ),
				'desc' => __( 'This setting will override the global setting above. Leave blank for theme option selection.', 'azkaban-core' ),
				'options' => $icons
			),
			'iconcolor' => array(
				'type' => 'colorpicker',
				'label' => __( 'Icon Color', 'azkaban-core' ),
				'desc' => __( 'This setting will override the global setting above. Leave blank for theme option selection.', 'azkaban-core')
			),
			'circle' => array(
				'type' => 'select',
				'label' => __( 'Icon in Circle', 'azkaban-core' ),
				'desc' => __( 'This setting will override the global setting above. Leave blank for theme option selection.', 'azkaban-core' ),
				'options' => $choices_with_default
			),
			'circlecolor' => array(
				'type' => 'colorpicker',
				'label' => __( 'Circle Color', 'azkaban-core' ),
				'desc' => __( 'This setting will override the global setting above. Leave blank for theme option selection.', 'azkaban-core')
			),				
			'content' => array(
				'std' => 'Your Content Goes Here',
				'type' => 'textarea',
				'label' => __( 'List Item Content', 'azkaban-core' ),
				'desc' => __( 'Add list item content', 'azkaban-core' ),
			),
		),
		'shortcode' => '[li_item icon="{{icon}}" iconcolor="{{iconcolor}}" circle="{{circle}}" circlecolor="{{circlecolor}}"]{{content}}[/li_item]',
		'clone_button' => __( 'Add New List Item', 'azkaban-core')
	)
);


/*-----------------------------------------------------------------------------------*/
/*	Client Slider Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['clientslider'] = array(
	'params' => array(
		'picture_size' => array(
			'type' => 'select',
			'label' => __( 'Picture Size', 'azkaban-core' ),
			'desc' => __( 'fixed = width and height will be fixed <br />auto = width and height will adjust to the image.', 'azkaban-core' ),
			'options' => array(
				'fixed' => 'Fixed',
				'auto' => 'Auto'
			)
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),		
	),
	'shortcode' => '[clients picture_size="{{picture_size}}" class="{{class}}" id="{{id}}"]{{child_shortcode}}[/clients]', // as there is no wrapper shortcode
	'popup_title' => __( 'Client Slider Shortcode', 'azkaban-core' ),
	'no_preview' => true,

	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'url' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Client Website Link', 'azkaban-core' ),
				'desc' => __( 'Add the url to client\'s website <br />ex: http://example.com', 'azkaban-core')
			),
			'target' => array(
				'type' => 'select',
				'label' => __( 'Link Target', 'azkaban-core' ),
				'desc' => __( '_self = open in same window <br /> _blank = open in new window', 'azkaban-core' ),
				'options' => array(
					'_self' => '_self',
					'_blank' => '_blank'
				)
			),
			'image' => array(
				'type' => 'uploader',
				'label' => __( 'Client Image', 'azkaban-core' ),
				'desc' => __( 'Upload the client image', 'azkaban-core' ),
			),
			'alt' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Image Alt Text', 'azkaban-core' ),
				'desc' => 'The alt attribute provides alternative information if an image cannot be viewed'
			),				
		),
		'shortcode' => '[client link="{{url}}" linktarget="{{target}}" image="{{image}}" alt="{{alt}}"]',
		'clone_button' => __( 'Add New Client Image', 'azkaban-core')
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Columns Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['columns'] = array(
	'shortcode' => ' {{child_shortcode}} ', // as there is no wrapper shortcode
	'popup_title' => __( 'Insert Columns Shortcode', 'azkaban-core' ),
	'no_preview' => true,
	'params' => array(),

	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'column' => array(
				'type' => 'select',
				'label' => __( 'Column Type', 'azkaban-core' ),
				'desc' => __( 'Select the width of the column', 'azkaban-core' ),
				'options' => array(
					'one_third' => 'One Third',
					'two_third' => 'Two Thirds',
					'one_half' => 'One Half',
					'one_fourth' => 'One Fourth',
					'three_fourth' => 'Three Fourth',
				)
			),
			'last' => array(
				'type' => 'select',
				'label' => __( 'Last Column', 'azkaban-core' ),
				'desc' => 'Choose if the column is last in a set. This has to be set to "Yes" for the last column in a set',
				'options' => $reverse_choices
			),
			'content' => array(
				'std' => '',
				'type' => 'textarea',
				'label' => __( 'Column Content', 'azkaban-core' ),
				'desc' => __( 'Insert the column content', 'azkaban-core' ),
			),
			'class' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'CSS Class', 'azkaban-core' ),
				'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
			),
			'id' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'CSS ID', 'azkaban-core' ),
				'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
			),			
		),
		'shortcode' => '[{{column}} last="{{last}}" class="{{class}}" id="{{id}}"]{{content}}[/{{column}}] ',
		'clone_button' => __( 'Add Column', 'azkaban-core')
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Content Boxes Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['contentboxes'] = array(
	'params' => array(

		'layout' => array(
			'type' => 'select',
			'label' => __( 'Box Layout', 'azkaban-core' ),
			'desc' => __( 'Select the layout for the content box', 'azkaban-core' ),
			'options' => array(
				'icon-with-title' => 'Icon beside Title',
				'icon-on-top' => 'Icon on Top of Title',
				'icon-on-side' => 'Icon beside Title and Content aligned with Title',
				'icon-boxed' => 'Icon Boxed',
			)
		),
		'columns' => array(
			'std' => 4,
			'type' => 'select',
			'label' => __( 'Number of Columns', 'azkaban-core' ),
			'desc' =>  __( 'Set the number of columns per row.', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 5, false )
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),			
	),
	'shortcode' => '[content_boxes layout="{{layout}}" columns="{{columns}}" class="{{class}}" id="{{id}}"]{{child_shortcode}}[/content_boxes]', // as there is no wrapper shortcode
	'popup_title' => __( 'Content Boxes Shortcode', 'azkaban-core' ),
	'no_preview' => true,

	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'title' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Title', 'azkaban-core')
			),
			'icon' => array(
				'type' => 'iconpicker',
				'label' => __( 'Icon', 'azkaban-core' ),
				'desc' => __( 'Click an icon to select, click again to deselect.', 'azkaban-core' ),
				'options' => $icons
			),
            'size' => array(
                'type' => 'select',
                'label' => __( 'Size of Icon', 'azkaban-core' ),
                'desc' => __( 'Select the size of the icon.', 'azkaban-core' ),
                'options' => array(
                    'lg' => 'Small',
                    '3x' => 'Medium',
                    '5x' => 'Large',
                )
            ),
			'backgroundcolor' => array(
				'type' => 'colorpicker',
				'label' => __( 'Content Box Background Color', 'azkaban-core' ),
				'desc' => __( 'This setting will override the global setting above. Leave blank for theme option selection.', 'azkaban-core')
			),			
			'iconcolor' => array(
				'type' => 'colorpicker',
				'label' => __( 'Icon Color', 'azkaban-core' ),
				'desc' => __( 'This setting will override the global setting above. Leave blank for theme option selection.', 'azkaban-core')
			),
			'circlecolor' => array(
				'type' => 'colorpicker',
				'label' => __( 'Icon Circle Background Color', 'azkaban-core' ),
				'desc' => __( 'This setting will override the global setting above. Leave blank for theme option selection.', 'azkaban-core')
			),
			'circlebordercolor' => array(
				'type' => 'colorpicker',
				'label' => __( 'Icon Circle Border Color', 'azkaban-core' ),
				'desc' => __( 'This setting will override the global setting above. Leave blank for theme option selection.', 'azkaban-core')
			),			
			'iconflip' => array(
				'type' => 'select',
				'label' => __( 'Flip Icon', 'azkaban-core' ),
				'desc' => __( 'Choose to flip the icon.', 'azkaban-core' ),
				'options' => array(
					''	=> 'None',
					'horizontal' => 'Horizontal',
					'vertical' => 'Vertical',
				)
			),
			'iconrotate' => array(
				'type' => 'select',
				'label' => __( 'Rotate Icon', 'azkaban-core' ),
				'desc' => __( 'Choose to rotate the icon.', 'azkaban-core' ),
				'options' => array(
					''	=> 'None',
					'90' => '90',
					'180' => '180',
					'270' => '270',					
				)
			),				
			'iconspin' => array(
				'type' => 'select',
				'label' => __( 'Spinning Icon', 'azkaban-core' ),
				'desc' => __( 'Choose to let the icon spin.', 'azkaban-core' ),
				'options' => $reverse_choices
			),									
			'image' => array(
				'type' => 'uploader',
				'label' => __( 'Icon Image', 'azkaban-core' ),
				'desc' => __( 'To upload your own icon image, deselect the icon above and then upload your icon image.', 'azkaban-core' ),
			),
			'image_width' => array(
				'std' => 35,
				'type' => 'text',
				'label' => __( 'Icon Image Width', 'azkaban-core' ),
				'desc' => __( 'If using an icon image, specify the image width in pixels but do not add px, ex: 35.', 'azkaban-core' ),
			),
			'image_height' => array(
				'std' => 35,
				'type' => 'text',
				'label' => __( 'Icon Image Height', 'azkaban-core' ),
				'desc' => __( 'If using an icon image, specify the image height in pixels but do not add px, ex: 35.', 'azkaban-core' ),
			),
			'link' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Read More Link Url', 'azkaban-core' ),
				'desc' => __( 'Add the link\'s url ex: http://example.com', 'azkaban-core' ),

			),
			'linktext' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Read More Link Text', 'azkaban-core' ),
				'desc' => __( 'Insert the text to display as the link', 'azkaban-core' ),

			),
			'target' => array(
				'type' => 'select',
				'label' => __( 'Read More Link Target', 'azkaban-core' ),
				'desc' => __( '_self = open in same window <br /> _blank = open in new window', 'azkaban-core' ),
				'options' => array(
					'_self' => '_self',
					'_blank' => '_blank'
				)
			),
			'content' => array(
				'std' => 'Your Content Goes Here',
				'type' => 'textarea',
				'label' => __( 'Content Box Content', 'azkaban-core' ),
				'desc' => __( 'Add content for content box', 'azkaban-core' ),
			),
		),
		'shortcode' => '[content_box title="{{title}}" backgroundcolor="{{backgroundcolor}}" icon="{{icon}}" size="{{size}}" iconcolor="{{iconcolor}}" circlecolor="{{circlecolor}}" circlebordercolor="{{circlebordercolor}}" iconflip="{{iconflip}}" iconrotate="{{iconrotate}}" iconspin="{{iconspin}}" image="{{image}}" image_width="{{image_width}}" image_height="{{image_height}}" link="{{link}}" linktarget="{{target}}" linktext="{{linktext}}"]{{content}}[/content_box]',
		'clone_button' => __( 'Add New Content Box', 'azkaban-core')
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Counters Box Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['countersbox'] = array(
	'params' => array(
		'columns' => array(
			'std' => 4,
			'type' => 'select',
			'label' => __( 'Number of Columns', 'azkaban-core' ),
			'desc' =>  __( 'Set the number of columns per row.', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 4, false )
		),	
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),
	),
	'shortcode' => '[counters_box columns="{{columns}}" class="{{class}}" id="{{id}}"]{{child_shortcode}}[/counters_box]', // as there is no wrapper shortcode
	'popup_title' => __( 'Counters Box Shortcode', 'azkaban-core' ),
	'no_preview' => true,

	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'value' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Counter Value', 'azkaban-core' ),
				'desc' => __( 'The number to which the counter will animate.', 'azkaban-core')
			),
			'unit' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Counter Box Unit', 'azkaban-core' ),
				'desc' => __( 'Insert a unit for the counter. ex %', 'azkaban-core' ),
			),
			'unitpos' => array(
				'type' => 'select',
				'label' => __( 'Unit Position', 'azkaban-core' ),
				'desc' => __( 'Choose the positioning of the unit.', 'azkaban-core' ),
				'options' => array(
					'suffix' => 'After Counter',
					'prefix' => 'Before Counter',
				)
			),
			'icon' => array(
				'type' => 'iconpicker',
				'label' => __( 'Icon', 'azkaban-core' ),
				'desc' => __( 'Click an icon to select, click again to deselect.', 'azkaban-core' ),
				'options' => $icons
			),			
			'border' => array(
				'type' => 'select',
				'label' => __( 'Show Border', 'azkaban-core' ),
				'desc' => __( 'Choose to show a box border.', 'azkaban-core' ),
				'options' => $choices
			),
			'color' => array(
				'type' => 'colorpicker',
				'label' => __( 'Color Of Counter', 'azkaban-core' ),
				'desc' => __( 'Controls the color of the counter text and icon. Leave blank for theme option selection.', 'azkaban-core')
			),
			'direction' => array(
				'type' => 'select',
				'label' => __( 'Counter Diection', 'azkaban-core' ),
				'desc' => __( 'Choose to count up or down.', 'azkaban-core' ),
				'options' => array(
					'up' => 'Countup',
					'down' => 'Countdown',
				)
			),			
			'content' => array(
				'std' => 'Text',
				'type' => 'text',
				'label' => __( 'Counter Box Text', 'azkaban-core' ),
				'desc' => __( 'Insert text for counter box', 'azkaban-core' ),
			)
		),
		'shortcode' => '[counter_box value="{{value}}" unit="{{unit}}" unit_pos="{{unitpos}}" icon="{{icon}}" border="{{border}}" color="{{color}}" direction="{{direction}}"]{{content}}[/counter_box]',
		'clone_button' => __( 'Add New Counter Box', 'azkaban-core')
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Counters Circle Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['counterscircle'] = array(
	'params' => array(
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),
	),
	'shortcode' => '[counters_circle class="{{class}}" id="{{id}}"]{{child_shortcode}}[/counters_circle]', // as there is no wrapper shortcode
	'popup_title' => __( 'Counters Circle Shortcode', 'azkaban-core' ),
	'no_preview' => true,

	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'value' => array(
				'type' => 'select',
				'label' => __( 'Filled Area Percentage', 'azkaban-core' ),
				'desc' => __( 'From 1% to 100%', 'azkaban-core' ),
				'options' => azkaban_shortcodes_range(100, false)
			),
			'filledcolor' => array(
				'type' => 'colorpicker',
				'label' => __( 'Filled Color', 'azkaban-core' ),
				'desc' => __( 'Controls the color of the filled in area. Leave blank for theme option selection.', 'azkaban-core')
			),
			'unfilledcolor' => array(
				'type' => 'colorpicker',
				'label' => __( 'Unfilled Color', 'azkaban-core' ),
				'desc' => __( 'Controls the color of the unfilled in area. Leave blank for theme option selection.', 'azkaban-core')
			),
			'size' => array(
				'std' => '220',
				'type' => 'text',
				'label' => __( 'Size of the Counter', 'azkaban-core' ),
				'desc' => __( 'Insert size of the counter in px. ex: 220', 'azkaban-core' ),
			),
			'scales' => array(
				'type' => 'select',
				'label' => __( 'Show Scales', 'azkaban-core' ),
				'desc' => __( 'Choose to show a scale around circles.', 'azkaban-core' ),
				'options' => $reverse_choices
			),		
			'countdown' => array(
				'type' => 'select',
				'label' => __( 'Countdown', 'azkaban-core' ),
				'desc' => __( 'Choose to let the circle filling move counter clockwise.', 'azkaban-core' ),
				'options' => $reverse_choices
			),					
			'speed' => array(
				'std' => '1500',
				'type' => 'text',
				'label' => __( 'Animation Speed', 'azkaban-core' ),
				'desc' => __( 'Insert animation speed in milliseconds', 'azkaban-core' ),
			),
			'content' => array(
				'std' => 'Text',
				'type' => 'text',
				'label' => __( 'Counter Circle Text', 'azkaban-core' ),
				'desc' => __( 'Insert text for counter circle box, keep it short', 'azkaban-core' ),
			),			
		),
		'shortcode' => '[counter_circle filledcolor="{{filledcolor}}" unfilledcolor="{{unfilledcolor}}" size="{{size}}" scales="{{scales}}" countdown="{{countdown}}" speed="{{speed}}" value="{{value}}"]{{content}}[/counter_circle]',
		'clone_button' => __( 'Add New Counter Circle', 'azkaban-core')
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Dropcap Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['dropcap'] = array(
	'no_preview' => true,
	'params' => array(
		'content' => array(
			'std' => 'A',
			'type' => 'textarea',
			'label' => __( 'Dropcap Letter', 'azkaban-core' ),
			'desc' => __( 'Add the letter to be used as dropcap', 'azkaban-core' ),
		),
		'color' => array(
			'type' => 'colorpicker',
			'label' => __( 'Color', 'azkaban-core' ),
			'desc' => __( 'Controls the color of the dropcap letter. Leave blank for theme option selection.', 'azkaban-core ')
		),		
		'boxed' => array(
			'type' => 'select',
			'label' => __( 'Boxed Dropcap', 'azkaban-core' ),
			'desc' => __( 'Choose to get a boxed dropcap.', 'azkaban-core' ),
			'options' => $reverse_choices
		),
		'boxedradius' => array(
			'std' => '8px',
			'type' => 'text',
			'label' => __( 'Box Radius', 'azkaban-core' ),
			'desc' => 'Choose the radius of the boxed dropcap. In pixels (px), ex: 1px, or "round".'
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),
	),
	'shortcode' => '[dropcap color="{{color}}" boxed="{{boxed}}" boxed_radius="{{boxedradius}}" class="{{class}}" id="{{id}}"]{{content}}[/dropcap]',
	'popup_title' => __( 'Dropcap Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Post Slider Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['postslider'] = array(
	'no_preview' => true,
	'params' => array(

		'type' => array(
			'type' => 'select',
			'label' => __( 'Layout', 'azkaban-core' ),
			'desc' => __( 'Choose a layout style for Post Slider.', 'azkaban-core' ),
			'options' => array(
				'posts' => 'Posts with Title',
				'posts-with-excerpt' => 'Posts with Title and Excerpt',
				'attachments' => 'Attachment Layout, Only Images Attached to Post/Page'
			)
		),
		'excerpt' => array(
			'std' => 35,
			'type' => 'select',
			'label' => __( 'Excerpt Number of Words', 'azkaban-core' ),
			'desc' => __( 'Insert the number of words you want to show in the excerpt.', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 50, false)
		),
		'category' => array(
			'std' => 35,
			'type' => 'select',
			'label' => __( 'Category', 'azkaban-core' ),
			'desc' => __( 'Select a category of posts to display.', 'azkaban-core' ),
			'options' => azkaban_shortcodes_categories( 'category', true )
		),
		'limit' => array(
			'std' => 3,
			'type' => 'select',
			'label' => __( 'Number of Slides', 'azkaban-core' ),
			'desc' => __( 'Select the number of slides to display.', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 10, false )
		),
		'lightbox' => array(
			'type' => 'select',
			'label' => __( 'Lightbox on Click', 'azkaban-core' ),
			'desc' => __( 'Only works on attachment layout.', 'azkaban-core' ),
			'options' => $choices
		),
		'image' => array(
			'type' => 'gallery',
			'label' => __( 'Attach Images to Post/Page Gallery', 'azkaban-core' ),
			'desc' => __( 'Only works for attachments layout.', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),		
	),
	'shortcode' => '[postslider layout="{{type}}" excerpt="{{excerpt}}" category="{{category}}" limit="{{limit}}" id="" lightbox="{{lightbox}}" class="{{class}}" id="{{id}}"][/postslider]',
	'popup_title' => __( 'Post Slider Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	FontAwesome Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['fontawesome'] = array(
	'no_preview' => true,
	'params' => array(

		'icon' => array(
			'type' => 'iconpicker',
			'label' => __( 'Select Icon', 'azkaban-core' ),
			'desc' => __( 'Click an icon to select, click again to deselect.', 'azkaban-core' ),
			'options' => $icons
		),
		'circle' => array(
			'type' => 'select',
			'label' => __( 'Icon in Circle', 'azkaban-core' ),
			'desc' => __( 'Choose to display the icon in a circle.', 'azkaban-core' ),
			'options' => $choices
		),
		'size' => array(
			'type' => 'select',
			'label' => __( 'Size of Icon', 'azkaban-core' ),
			'desc' => __( 'Select the size of the icon.', 'azkaban-core' ),
			'options' => array(
				'small' => 'Small',
				'medium' => 'Medium',
				'large' => 'Large',
			)
		),
		'iconcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Icon Color', 'azkaban-core' ),
			'desc' => __( 'Controls the color of the icon. Leave blank for theme option selection.', 'azkaban-core')
		),
		'circlecolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Icon Circle Background Color', 'azkaban-core' ),
			'desc' => __( 'Controls the color of the circle. Leave blank for theme option selection.', 'azkaban-core')
		),
		'circlebordercolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Icon Circle Border Color', 'azkaban-core' ),
			'desc' => __( 'Controls the color of the circle border. Leave blank for theme option selection.', 'azkaban-core')
		),
		'flip' => array(
			'type' => 'select',
			'label' => __( 'Flip Icon', 'azkaban-core' ),
			'desc' => __( 'Choose to flip the icon.', 'azkaban-core' ),
			'options' => array(
				''	=> 'None',
				'horizontal' => 'Horizontal',
				'vertical' => 'Vertical',
			)
		),
		'rotate' => array(
			'type' => 'select',
			'label' => __( 'Rotate Icon', 'azkaban-core' ),
			'desc' => __( 'Choose to rotate the icon.', 'azkaban-core' ),
			'options' => array(
				''	=> 'None',
				'90' => '90',
				'180' => '180',
				'270' => '270',					
			)
		),				
		'spin' => array(
			'type' => 'select',
			'label' => __( 'Spinning Icon', 'azkaban-core' ),
			'desc' => __( 'Choose to let the icon spin.', 'azkaban-core' ),
			'options' => $reverse_choices
		),		
		'animation_type' => array(
			'type' => 'select',
			'label' => __( 'Animation Type', 'azkaban-core' ),
			'desc' => __( 'Select the type on animation to use on the shortcode.', 'azkaban-core' ),
			'options' => array(
				'0' => 'None',
				'bounce' => 'Bounce',
				'fade' => 'Fade',
				'flash' => 'Flash',
				'shake' => 'Shake',
				'slide' => 'Slide',
			)
		),
		'animation_direction' => array(
			'type' => 'select',
			'label' => __( 'Direction of Animation', 'azkaban-core' ),
			'desc' => __( 'Select the incoming direction for the animation.', 'azkaban-core' ),
			'options' => array(
				'down' => 'Down',
				'left' => 'Left',
				'right' => 'Right',
				'up' => 'Up',
			)
		),
		'animation_speed' => array(
			'type' => 'select',
			'std' => '',
			'label' => __( 'Speed of Animation', 'azkaban-core' ),
			'desc' => __( 'Type in speed of animation in seconds (0.1 - 1).', 'azkaban-core' ),
			'options' => $dec_numbers,
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),		
	),
	'shortcode' => '[fontawesome icon="{{icon}}" circle="{{circle}}" size="{{size}}" iconcolor="{{iconcolor}}" circlecolor="{{circlecolor}}" circlebordercolor="{{circlebordercolor}}" flip="{{flip}}" rotate="{{rotate}}" spin="{{spin}}" animation_type="{{animation_type}}" animation_direction="{{animation_direction}}" animation_speed="{{animation_speed}}" class="{{class}}" id="{{id}}"]',
	'popup_title' => __( 'Font Awesome Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Fullwidth Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['fullwidth'] = array(
	'no_preview' => true,
	'params' => array(
		'color' => array(
			'type' => 'colorpicker',
			'label' => __( 'Text Color', 'azkaban-core' ),
			'desc' => __( 'Controls the text color.  Leave blank for theme option selection.', 'azkaban-core')
		),
		'backgroundcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Background Color', 'azkaban-core' ),
			'desc' => __( 'Controls the background color.  Leave blank for theme option selection.', 'azkaban-core')
		),
		'backgroundimage' => array(
			'type' => 'uploader',
			'label' => __( 'Backgrond Image', 'azkaban-core' ),
			'desc' => 'Upload an image to display in the background'
		),
		'backgroundrepeat' => array(
			'type' => 'select',
			'label' => __( 'Background Repeat', 'azkaban-core' ),
			'desc' => 'Choose how the background image repeats.',
			'options' => array(
				'no-repeat' => 'No Repeat',
				'repeat' => 'Repeat Vertically and Horizontally',
				'repeat-x' => 'Repeat Horizontally',
				'repeat-y' => 'Repeat Vertically'
			)
		),
		'backgroundposition' => array(
			'type' => 'select',
			'label' => __( 'Background Position', 'azkaban-core' ),
			'desc' => 'Choose the postion of the background image',
			'options' => array(
				'left top' => 'Left Top',
				'left center' => 'Left Center',
				'left bottom' => 'Left Bottom',
				'right top' => 'Right Top',
				'right center' => 'Right Center',
				'right bottom' => 'Right Bottom',
				'center top' => 'Center Top',
				'center center' => 'Center Center',
				'center bottom' => 'Center Bottom'
			)
		),
		'backgroundattachment' => array(
			'type' => 'select',
			'label' => __( 'Background Scroll', 'azkaban-core' ),
			'desc' => 'Choose how the background image scrolls',
			'options' => array(
				'scroll' => 'Scroll: background scrolls along with the element',
				'fixed' => 'Fixed: background is fixed giving a parallax effect',
				'local' => 'Local: background scrolls along with the element\'s contents'
			)
		),
		'bordersize' => array(
			'std' => '0px',
			'type' => 'text',
			'label' => __( 'Border Size', 'azkaban-core' ),
			'desc' => __( 'In pixels (px), ex: 1px. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'bordercolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Border Color', 'azkaban-core' ),
			'desc' => __( 'Controls the border color.  Leave blank for theme option selection.', 'azkaban-core')
		),
		'borderstyle' => array(
			'type' => 'select',
			'label' => __( 'Border Style', 'azkaban-core' ),
			'desc' => __( 'Controls the border style.', 'azkaban-core' ),
			'options' => array(
				'solid' => 'Solid',
				'dashed' => 'Dashed',
				'dotted' => 'Dotted'
			)			
		),		
		'paddingtop' => array(
			'std' => 20,
			'type' => 'select',
			'label' => __( 'Padding Top', 'azkaban-core' ),
			'desc' => __( 'In pixels', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 100, false )
		),
		'paddingbottom' => array(
			'std' => 20,
			'type' => 'select',
			'label' => __( 'Padding Bottom', 'azkaban-core' ),
			'desc' => __( 'In pixels', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 100, false )
		),
		'margintop' => array(
			'std' => 0,
			'type' => 'select',
			'label' => __( 'Margin Top', 'azkaban-core' ),
			'desc' => __( 'In pixels', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 50, false, false, -50 )
		),
		'marginbottom' => array(
			'std' => 0,
			'type' => 'select',
			'label' => __( 'Margin Bottom', 'azkaban-core' ),
			'desc' => __( 'In pixels', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 50, false, false, -50 )
		),
		'menuanchor' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Name Of Menu Anchor', 'azkaban-core' ),
			'desc' => 'This name will be the id you will have to use in your one page menu.',
		),
		'content' => array(
			'std' => 'Your Content Goes Here',
			'type' => 'textarea',
			'label' => __( 'Content', 'azkaban-core' ),
			'desc' => __( 'Add content', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),			
	),
	'shortcode' => '[fullwidth menu_anchor="{{menuanchor}}" color="{{color}}" backgroundcolor="{{backgroundcolor}}" backgroundimage="{{backgroundimage}}" backgroundrepeat="{{backgroundrepeat}}" backgroundposition="{{backgroundposition}}" backgroundattachment="{{backgroundattachment}}" bordersize="{{bordersize}}" bordercolor="{{bordercolor}}" borderstyle="{{borderstyle}}" paddingtop="{{paddingtop}}px" paddingbottom="{{paddingbottom}}px" margintop="{{margintop}}px" marginbottom="{{marginbottom}}px" class="{{class}}" id="{{id}}"]{{content}}[/fullwidth]',
	'popup_title' => __( 'Fullwidth Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Highlight Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['highlight'] = array(
	'no_preview' => true,
	'params' => array(

		'color' => array(
			'type' => 'colorpicker',
			'label' => __( 'Highlight Color', 'azkaban-core' ),
			'desc' => __( 'Pick a highlight color', 'azkaban-core')
		),
		'rounded' => array(
			'type' => 'select',
			'label' => __( 'Highlight With Round Edges', 'azkaban-core' ),
			'desc' => __( 'Choose to have rounded edges.', 'azkaban-core' ),
			'options' => $reverse_choices
		),		
		'content' => array(
			'std' => 'Your Content Goes Here',
			'type' => 'textarea',
			'label' => __( 'Content to Higlight', 'azkaban-core' ),
			'desc' => __( 'Add your content to be highlighted', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core')
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core')
		),			

	),
	'shortcode' => '[highlight color="{{color}}" rounded="{{rounded}}" class="{{class}}" id="{{id}}"]{{content}}[/highlight]',
	'popup_title' => __( 'Highlight Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Person Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['person'] = array(
	'no_preview' => true,
	'params' => array(
		'name' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Name', 'azkaban-core' ),
			'desc' => __( 'Insert the name of the person.', 'azkaban-core' ),
		),
		'title' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Title', 'azkaban-core' ),
			'desc' => __( 'Insert the title of the person', 'azkaban-core' ),
		),
		'content' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Profile Description', 'azkaban-core' ),
			'desc' => __( 'Enter the content to be displayed', 'azkaban-core' )
		),
		'picture' => array(
			'type' => 'uploader',
			'label' => __( 'Picture', 'azkaban-core' ),
			'desc' => __( 'Upload an image to display.', 'azkaban-core' ),
		),
		'piclink' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Picture Link URL', 'azkaban-core' ),
			'desc' => __( 'Add the URL the picture will link to, ex: http://example.com.', 'azkaban-core' ),
		),
		'picstyle' => array(
			'type' => 'select',
			'label' => __( 'Picture Style Type', 'azkaban-core' ),
			'desc' => __( 'Selected the style type for the picture,', 'azkaban-core' ),
			'options' => array(
				'none' => 'None',
				'border' => 'Border',
				'glow' => 'Glow',
				'dropshadow' => 'Drop Shadow',
				'bottomshadow' => 'Bottom Shadow'
			)
		),
		'pic_style_color' => array(
			'type' => 'colorpicker',
			'label' => __( 'Picture Style color', 'azkaban-core' ),
			'desc' => __( 'For all style types except border. Controls the style color. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'picborder' => array(
			'std' => '0',
			'type' => 'text',
			'label' => __( 'Picture Border Size', 'azkaban-core' ),
			'desc' => __( 'In pixels (px), ex: 1px. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'picbordercolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Picture Border Color', 'azkaban-core' ),
			'desc' => __( 'Controls the picture\'s border color. Leave blank for theme option selection.', 'azkaban-core' ),
		),		
		'iconboxed' => array(
			'type' => 'select',
			'label' => __( 'Boxed Social Icons', 'azkaban-core' ),
			'desc' => __( 'Choose to get a boxed icons. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => $reverse_choices_with_default
		),
		'iconboxedradius' => array(
			'std' => '4px',
			'type' => 'text',
			'label' => __( 'Social Icon Box Radius', 'azkaban-core' ),
			'desc' => __( 'Choose the radius of the boxed icons. In pixels (px), ex: 1px, or "round". Leave blank for theme option selection.', 'azkaban-core' ),
		),		
		'iconcolor' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Social Icon Custom Colors', 'azkaban-core' ),
			'desc' => __( 'Specify the color of social icons. Use one for all or separate by | symbol. 
ex: #AA0000|#00AA00|#0000AA.  Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'boxcolor' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Social Icon Custom Box Colors', 'azkaban-core' ),
			'desc' => __( 'Specify the box color of social icons. Use one for all or separate by | symbol. 
ex: #AA0000|#00AA00|#0000AA. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'icontooltip' => array(
			'type' => 'select',
			'label' => __( 'Social Icon Tooltip Position', 'azkaban-core' ),
			'desc' => __( 'Choose the display position for tooltips. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => array(
				'' => 'Default',
				'top' => 'Top',
				'bottom' => 'Bottom',
				'left' => 'Left',
				'Right' => 'Right',
			)
		),			
		'email' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Email Address', 'azkaban-core' ),
			'desc' => __( 'Insert an email address to display the email icon', 'azkaban-core' ),
		),
		'facebook' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Facebook Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Facebook link', 'azkaban-core' ),
		),
		'twitter' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Twitter Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Twitter link', 'azkaban-core' ),
		),
		'instagram' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Instagram Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Instagram link', 'azkaban-core' ),
		),
		'dribbble' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Dribbble Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Dribbble link', 'azkaban-core' ),
		),
		'google' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Google+ Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Google+ link', 'azkaban-core' ),
		),
		'linkedin' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'LinkedIn Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom LinkedIn link', 'azkaban-core' ),
		),
		'blogger' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Blogger Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Blogger link', 'azkaban-core' ),
		),
		'tumblr' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Tumblr Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Tumblr link', 'azkaban-core' ),
		),
		'reddit' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Reddit Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Reddit link', 'azkaban-core' ),
		),
		'yahoo' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Yahoo Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Yahoo link', 'azkaban-core' ),
		),
		'deviantart' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Deviantart Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Deviantart link', 'azkaban-core' ),
		),
		'vimeo' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Vimeo Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Vimeo link', 'azkaban-core' ),
		),
		'youtube' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Youtube Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Youtube link', 'azkaban-core' ),
		),
		'pinterest' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Pinterst Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Pinterest link', 'azkaban-core' ),
		),
		'rss' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'RSS Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom RSS link', 'azkaban-core' ),
		),		
		'digg' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Digg Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Digg link', 'azkaban-core' ),
		),
		'flickr' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Flickr Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Flickr link', 'azkaban-core' ),
		),
		'forrst' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Forrst Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Forrst link', 'azkaban-core' ),
		),
		'myspace' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Myspace Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Myspace link', 'azkaban-core' ),
		),
		'skype' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Skype Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Skype link', 'azkaban-core' ),
		),
		'paypal' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'PayPal Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom paypal link', 'azkaban-core' ),
		),
		'dropbox' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Dropbox Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom dropbox link', 'azkaban-core' ),
		),
		'soundcloud' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'SoundCloud Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom soundcloud link', 'azkaban-core' ),
		),
		'vk' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'VK Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom vk link', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),
	),
	'shortcode' => '[person name="{{name}}" title="{{title}}" picture="{{picture}}" pic_link="{{piclink}}" pic_style="{{picstyle}}" pic_style_color="{{pic_style_color}}" pic_bordersize="{{picborder}}" pic_bordercolor="{{picbordercolor}}"  social_icon_boxed="{{iconboxed}}" social_icon_boxed_radius="{{iconboxedradius}}" social_icon_colors="{{iconcolor}}"  social_icon_boxed_colors="{{boxcolor}}" social_icon_tooltip="{{icontooltip}}" email="{{email}}" facebook="{{facebook}}" twitter="{{twitter}}" instagram="{{instagram}}" dribbble="{{dribbble}}" google="{{google}}" linkedin="{{linkedin}}" blogger="{{blogger}}" tumblr="{{tumblr}}" reddit="{{reddit}}" yahoo="{{yahoo}}" deviantart="{{deviantart}}" vimeo="{{vimeo}}" youtube="{{youtube}}" rss="{{rss}}" pinterest="{{pinterest}}" digg="{{digg}}" flickr="{{flickr}}" forrst="{{forrst}}" myspace="{{myspace}}" skype="{{skype}}" paypal="{{paypal}}" dropbox="{{dropbox}}" soundcloud="{{soundcloud}}" vk="{{vk}}" class="{{class}} id="{{id}}"]{{content}}[/person]',
	'popup_title' => __( 'Person Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Progress Bar Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['progressbar'] = array(
	'params' => array(

		'percentage' => array(
			'type' => 'select',
			'label' => __( 'Filled Area Percentage', 'azkaban-core' ),
			'desc' => __( 'From 1% to 100%', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 100, false )
		),
		'unit' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Progress Bar Unit', 'azkaban-core' ),
			'desc' => __( 'Insert a unit for the progress bar. ex %', 'azkaban-core' ),
		),
		'filledcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Filled Color', 'azkaban-core' ),
			'desc' => __( 'Controls the color of the filled in area. Leave blank for theme option selection.', 'azkaban-core' )
		),
		'unfilledcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Unfilled Color', 'azkaban-core' ),
			'desc' => __( 'Controls the color of the unfilled in area. Leave blank for theme option selection.', 'azkaban-core' )
		),
		'striped' => array(
			'type' => 'select',
			'label' => __( 'Striped Filling', 'azkaban-core' ),
			'desc' => __( 'Choose to get the filled area striped.', 'azkaban-core' ),
			'options' => $reverse_choices
		),
		'animatedstripes' => array(
			'type' => 'select',
			'label' => __( 'Animated Stripes', 'azkaban-core' ),
			'desc' => __( 'Choose to get the the stripes animated.', 'azkaban-core' ),
			'options' => $reverse_choices
		),			
		'textcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Text Color', 'azkaban-core' ),
			'desc' => __( 'Controls the text color. Leave blank for theme option selection.', 'azkaban-core ')
		),
		'content' => array(
			'std' => 'Text',
			'type' => 'text',
			'label' => __( 'Progess Bar Text', 'azkaban-core' ),
			'desc' => __( 'Text will show up on progess bar', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),		
	),
	'shortcode' => '[progress percentage="{{percentage}}" unit="{{unit}}" filledcolor="{{filledcolor}}" unfilledcolor="{{unfilledcolor}}" striped="{{striped}}" animated_stripes="{{animatedstripes}}" textcolor="{{textcolor}}" class="{{class}}" id="{{id}}"]{{content}}[/progress]',
	'popup_title' => __( 'Progress Bar Shortcode', 'azkaban-core' ),
	'no_preview' => true,
);

/*-----------------------------------------------------------------------------------*/
/*	Recent Posts Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['recentposts'] = array(
	'no_preview' => true,
	'params' => array(

		'layout' => array(
			'type' => 'select',
			'label' => __( 'Layout', 'azkaban-core' ),
			'desc' => 'Select the layout for the shortcode',
			'options' => array(
				'default' => 'Default',
				'thumbnails-on-side' => 'Thumbnails on Side',
				'date-on-side' => 'Date on Side',
			)
		),
		'columns' => array(
			'type' => 'select',
			'label' => __( 'Columns', 'azkaban-core' ),
			'desc' => __( 'Select the number of columns to display', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 4, false )
		),
		'number_posts' => array(
			'std' => 4,
			'type' => 'select',
			'label' => __( 'Number of Posts', 'azkaban-core' ),
			'desc' => 'Select the number of posts to display',
			'options' => azkaban_shortcodes_range( 12, false )
		),
		'cat_slug' => array(
			'type' => 'multiple_select',
			'label' => __( 'Categories', 'azkaban-core' ),
			'desc' => __( 'Select a category or leave blank for all', 'azkaban-core' ),
			'options' => azkaban_shortcodes_categories( 'category' )
		),
		'exclude_cats' => array(
			'type' => 'multiple_select',
			'label' => __( 'Exclude Categories', 'azkaban-core' ),
			'desc' => __( 'Select a category to exclude', 'azkaban-core' ),
			'options' => azkaban_shortcodes_categories( 'category' )
		),
		'thumbnail' => array(
			'type' => 'select',
			'label' => __( 'Show Thumbnail', 'azkaban-core' ),
			'desc' => 'Display the post featured image',
			'options' => $choices
		),
		'title' => array(
			'type' => 'select',
			'label' => __( 'Show Title', 'azkaban-core' ),
			'desc' => 'Display the post title below the featured image',
			'options' => $choices
		),
		'meta' => array(
			'type' => 'select',
			'label' => __( 'Show Meta', 'azkaban-core' ),
			'desc' => 'Choose to show all meta data',
			'options' => $choices
		),
		'excerpt' => array(
			'type' => 'select',
			'label' => __( 'Show Excerpt', 'azkaban-core' ),
			'desc' => 'Choose to display the post excerpt',
			'options' => $choices
		),
		'excerpt_length' => array(
			'std' => 35,
			'type' => 'select',
			'label' => __( 'Excerpt Length', 'azkaban-core' ),
			'desc' => 'Insert the number of words/characters you want to show in the excerpt',
			'options' => azkaban_shortcodes_range( 60, false )
		),
		'strip_html' => array(
			'type' => 'select',
			'label' => __( 'Strip HTML', 'azkaban-core' ),
			'desc' => 'Strip HTML from the post excerpt',
			'options' => $choices
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[recent_posts layout="{{layout}}" columns="{{columns}}" number_posts="{{number_posts}}" cat_slug="{{cat_slug}}" exclude_cats="{{exclude_cats}}" thumbnail="{{thumbnail}}" title="{{title}}" meta="{{meta}}" excerpt="{{excerpt}}" excerpt_length="{{excerpt_length}}" strip_html="{{strip_html}}" animation_type="{{animation_type}}" animation_direction="{{animation_direction}}" animation_speed="{{animation_speed}}" class="{{class}}" id="{{id}}"][/recent_posts]',
	'popup_title' => __( 'Recent Posts Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Recent Works Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['recentworks'] = array(
	'no_preview' => true,
	'params' => array(
		'layout' => array(
			'type' => 'select',
			'label' => __( 'Layout', 'azkaban-core' ),
			'desc' => 'Choose the layout for the shortcode',
			'options' => array(
				'carousel' => 'Carousel',
				'grid' => 'Grid',
				'grid-with-excerpts' => 'Grid with Excerpts',
			)
		),
		'picture_size' => array(
			'type' => 'select',
			'label' => __( 'Picture Size For Carousel Layout', 'azkaban-core' ),
			'desc' => __( 'fixed = width and height will be fixed <br />auto = width and height will adjust to the image.<br />only works with carousel layout.', 'azkaban-core' ),
			'options' => array(
				'fixed' => 'Fixed',
				'auto' => 'Auto'
			)
		),
		'filters' => array(
			'type' => 'select',
			'label' => __( 'Show Filters', 'azkaban-core' ),
			'desc' => 'Choose to show or hide the category filters',
			'options' => $choices
		),
		'columns' => array(
			'type' => 'select',
			'label' => __( 'Columns', 'azkaban-core' ),
			'desc' => __( 'Select the number of columns to display', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 4, false )
		),
		'cat_slug' => array(
			'type' => 'multiple_select',
			'label' => __( 'Categories', 'azkaban-core' ),
			'desc' => __( 'Select a category or leave blank for all', 'azkaban-core' ),
			'options' => azkaban_shortcodes_categories( 'portfolio_category' )
		),
		'exclude_cats' => array(
			'type' => 'multiple_select',
			'label' => __( 'Exclude Categories', 'azkaban-core' ),
			'desc' => __( 'Select a category to exclude', 'azkaban-core' ),
			'options' => azkaban_shortcodes_categories( 'portfolio_category' )
		),		
		'number_posts' => array(
			'std' => 4,
			'type' => 'select',
			'label' => __( 'Number of Posts', 'azkaban-core' ),
			'desc' => 'Select the number of posts to display',
			'options' => azkaban_shortcodes_range( 12, false )
		),
		'excerpt_length' => array(
			'std' => 35,
			'type' => 'select',
			'label' => __( 'Excerpt Length', 'azkaban-core' ),
			'desc' => 'Insert the number of words/characters you want to show in the excerpt',
			'options' => azkaban_shortcodes_range( 60, false )
		),
		'animation_type' => array(
			'type' => 'select',
			'label' => __( 'Animation Type', 'azkaban-core' ),
			'desc' => __( 'Select the type on animation to use on the shortcode', 'azkaban-core' ),
			'options' => array(
				'0' => 'None',
				'bounce' => 'Bounce',
				'fade' => 'Fade',
				'flash' => 'Flash',
				'shake' => 'Shake',
				'slide' => 'Slide',
			)
		),
		'animation_direction' => array(
			'type' => 'select',
			'label' => __( 'Direction of Animation', 'azkaban-core' ),
			'desc' => __( 'Select the incoming direction for the animation', 'azkaban-core' ),
			'options' => array(
				'down' => 'Down',
				'left' => 'Left',
				'right' => 'Right',
				'up' => 'Up',
			)
		),
		'animation_speed' => array(
			'type' => 'select',
			'std' => '',
			'label' => __( 'Speed of Animation', 'azkaban-core' ),
			'desc' => __( 'Type in speed of animation in seconds (0.1 - 1)', 'azkaban-core' ),
			'options' => $dec_numbers,
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[recent_works picture_size="{{picture_size}}" layout="{{layout}}" filters="{{filters}}" columns="{{columns}}" cat_slug="{{cat_slug}}" exclude_cats="{{exclude_cats}}" number_posts="{{number_posts}}" excerpt_length="{{excerpt_length}}" animation_type="{{animation_type}}" animation_direction="{{animation_direction}}" animation_speed="{{animation_speed}}" class="{{class}}" id="{{id}}"][/recent_works]',
	'popup_title' => __( 'Recent Works Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Section Separator Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['sectionseparator'] = array(
	'no_preview' => true,
	'params' => array(
		'divider_candy' => array(
			'type' => 'select',
			'label' => __( 'Position of the Divider Candy', 'azkaban-core' ),
			'desc' => __( 'Select the position of the triangle candy', 'azkaban-core' ),
			'options' => array(
				'top' => 'Top',
				'bottom' => 'Bottom',
				'bottom,top' => 'Top and Bottom',
			)
		),
		'icon' => array(
			'type' => 'iconpicker',
			'label' => __( 'Select Icon', 'azkaban-core' ),
			'desc' => __( 'Click an icon to select, click again to deselect', 'azkaban-core' ),
			'options' => $icons
		),
		'iconcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Icon Color', 'azkaban-core' ),
			'desc' => __( 'Leave blank for theme option selection.', 'azkaban-core' )
		),
		'border' => array(
			'std' => '1px',
			'type' => 'text',
			'label' => __( 'Border Size', 'azkaban-core' ),
			'desc' => __( 'In pixels (px), ex: 1px. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'bordercolor' => array(
			'type' => 'colorpicker',
			'std' => '',
			'label' => __( 'Border Color', 'azkaban-core' ),
			'desc' => __( 'Controls the border color. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'backgroundcolor' => array(
			'type' => 'colorpicker',
			'std' => '',
			'label' => __( 'Background Color of Divider Candy', 'azkaban-core' ),
			'desc' => __( 'Controls the background color of the triangle. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[section_separator divider_candy="{{divider_candy}}" icon="{{icon}}" icon_color="{{iconcolor}}" bordersize="{{border}}" bordercolor="{{bordercolor}}" backgroundcolor="{{backgroundcolor}}" class="{{class}}" id="{{id}}"]',
	'popup_title' => __( 'Section Separator Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Separator Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['separator'] = array(
	'no_preview' => true,
	'params' => array(

		'style_type' => array(
			'type' => 'select',
			'label' => __( 'Style', 'azkaban-core' ),
			'desc' => __( 'Choose the separator line style', 'azkaban-core' ),
			'options' => array(
				'none' => 'No Style',
				'single' => 'Single Border Solid',
				'double' => 'Double Border Solid',
				'single|dashed' => 'Single Border Dashed',
				'double|dashed' => 'Double Border Dashed',
				'single|dotted' => 'Single Border Dotted',
				'double|dotted' => 'Double Border Dotted',
				'shadow' => 'Shadow'
			)
		),
		'topmargin' => array(
			'std' => 40,
			'type' => 'select',
			'label' => __( 'Margin Top', 'azkaban-core' ),
			'desc' => __( 'Spacing above the separator', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 100, false, false, 0 )
		),
		'bottommargin' => array(
			'std' => 40,
			'type' => 'select',
			'label' => __( 'Margin Bottom', 'azkaban-core' ),
			'desc' => __( 'Spacing below the separator', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 100, false, false, 0 )
		),
		'sepcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Separator Color', 'azkaban-core' ),
			'desc' => __( 'Controls the separator color. Leave blank for theme option selection.', 'azkaban-core' )
		),
		'icon' => array(
			'type' => 'iconpicker',
			'label' => __( 'Select Icon', 'azkaban-core' ),
			'desc' => __( 'Click an icon to select, click again to deselect', 'azkaban-core' ),
			'options' => $icons
		),			
		'width' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Separator Width', 'azkaban-core' ),
			'desc' => __( 'In pixels (px or %), ex: 1px, ex: 50%. Leave blank for full width.', 'azkaban-core' ),
		),		
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[separator style_type="{{style_type}}" top_margin="{{topmargin}}" bottom_margin="{{bottommargin}}"  sep_color="{{sepcolor}}" icon="{{icon}}" width="{{width}}" class="{{class}}" id="{{id}}"]',
	'popup_title' => __( 'Separator Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Sharing Box Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['sharingbox'] = array(
	'no_preview' => true,
	'params' => array(
		'tagline' => array(
			'std' => 'Share This Story, Choose Your Platform!',
			'type' => 'text',
			'label' => __( 'Tagline', 'azkaban-core' ),
			'desc' => 'The title tagline that will display'
		),
		'taglinecolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Tagline Color', 'azkaban-core' ),
			'desc' => __( 'Controls the text color. Leave blank for theme option selection.', 'azkaban-core')
		),
		'backgroundcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Background Color', 'azkaban-core' ),
			'desc' => __( 'Controls the background color. Leave blank for theme option selection.', 'azkaban-core')
		),
		'title' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Title', 'azkaban-core' ),
			'desc' => 'The post title that will be shared'
		),
		'link' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Link', 'azkaban-core' ),
			'desc' => 'The link that will be shared'
		),
		'description' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Description', 'azkaban-core' ),
			'desc' => 'The description that will be shared'
		),
		'link' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Link to Share', 'azkaban-core' ),
			'desc' => ''
		),
		'iconboxed' => array(
			'type' => 'select',
			'label' => __( 'Boxed Social Icons', 'azkaban-core' ),
			'desc' => __( 'Choose to get a boxed icons. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => $reverse_choices_with_default
		),
		'iconboxedradius' => array(
			'std' => '4px',
			'type' => 'text',
			'label' => __( 'Social Icon Box Radius', 'azkaban-core' ),
			'desc' => __( 'Choose the radius of the boxed icons. In pixels (px), ex: 1px, or "round". Leave blank for theme option selection.', 'azkaban-core' ),
		),	
		'iconcolor' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Social Icon Custom Colors', 'azkaban-core' ),
			'desc' => __( 'Specify the color of social icons. Use one for all or separate by | symbol. 
ex: #AA0000|#00AA00|#0000AA. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'boxcolor' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Social Icon Custom Box Colors', 'azkaban-core' ),
			'desc' => __( 'Specify the box color of social icons. Use one for all or separate by | symbol. 
ex: #AA0000|#00AA00|#0000AA. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'icontooltip' => array(
			'type' => 'select',
			'label' => __( 'Social Icon Tooltip Position', 'azkaban-core' ),
			'desc' => __( 'Choose the display position for tooltips. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => array(
				'' => 'Default',
				'top' => 'Top',
				'bottom' => 'Bottom',
				'left' => 'Left',
				'Right' => 'Right',
			)
		),		
		'pinterest_image' => array(
			'std' => '',
			'type' => 'uploader',
			'label' => __( 'Choose Image to Share on Pinterest', 'azkaban-core' ),
			'desc' => ''
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[sharing tagline="{{tagline}}" tagline_color="{{taglinecolor}}" title="{{title}}" link="{{link}}" description="{{description}}" pinterest_image="{{pinterest_image}}" icons_boxed="{{iconboxed}}" icons_boxed_radius="{{iconboxedradius}}" box_colors="{{boxcolor}}" icon_colors="{{iconcolor}}" tooltip_placement="{{icontooltip}}" backgroundcolor="{{backgroundcolor}}" class="{{class}}" id="{{id}}"][/sharing]',
	'popup_title' => __( 'Sharing Box Shortcode', 'azkaban-core' )
);


/*-----------------------------------------------------------------------------------*/
/*	Social Links Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['sociallinks'] = array(
	'no_preview' => true,
	'params' => array(
		'iconboxed' => array(
			'type' => 'select',
			'label' => __( 'Boxed Social Icons', 'azkaban-core' ),
			'desc' => __( 'Choose to get a boxed icons. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => $reverse_choices_with_default
		),
		'iconboxedradius' => array(
			'std' => '4px',
			'type' => 'text',
			'label' => __( 'Social Icon Box Radius', 'azkaban-core' ),
			'desc' => __( 'Choose the radius of the boxed icons. In pixels (px), ex: 1px, or "round". Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'iconcolor' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Social Icon Custom Colors', 'azkaban-core' ),
			'desc' => __( 'Specify the color of social icons. Use one for all or separate by | symbol. 
ex: #AA0000|#00AA00|#0000AA.  Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'boxcolor' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Social Icon Custom Box Colors', 'azkaban-core' ),
			'desc' => __( 'Specify the box color of social icons. Use one for all or separate by | symbol. 
ex: #AA0000|#00AA00|#0000AA. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'icontooltip' => array(
			'type' => 'select',
			'label' => __( 'Social Icon Tooltip Position', 'azkaban-core' ),
			'desc' => __( 'Choose the display position for tooltips. Choose default for theme option selection.', 'azkaban-core' ),
			'options' => array(
				'' => 'Default',
				'top' => 'Top',
				'bottom' => 'Bottom',
				'left' => 'Left',
				'Right' => 'Right',
			)
		),			
		'facebook' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Facebook Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Facebook link', 'azkaban-core' ),
		),
		'twitter' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Twitter Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Twitter link', 'azkaban-core' ),
		),
		'instagram' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Instagram Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Instagram link', 'azkaban-core' ),
		),
		'dribbble' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Dribbble Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Dribbble link', 'azkaban-core' ),
		),
		'google' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Google+ Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Google+ link', 'azkaban-core' ),
		),
		'linkedin' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'LinkedIn Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom LinkedIn link', 'azkaban-core' ),
		),
		'blogger' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Blogger Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Blogger link', 'azkaban-core' ),
		),
		'tumblr' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Tumblr Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Tumblr link', 'azkaban-core' ),
		),
		'reddit' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Reddit Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Reddit link', 'azkaban-core' ),
		),
		'yahoo' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Yahoo Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Yahoo link', 'azkaban-core' ),
		),
		'deviantart' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Deviantart Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Deviantart link', 'azkaban-core' ),
		),
		'vimeo' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Vimeo Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Vimeo link', 'azkaban-core' ),
		),
		'youtube' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Youtube Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Youtube link', 'azkaban-core' ),
		),
		'pinterest' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Pinterst Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Pinterest link', 'azkaban-core' ),
		),
		'rss' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'RSS Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom RSS link', 'azkaban-core' ),
		),		
		'digg' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Digg Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Digg link', 'azkaban-core' ),
		),
		'flickr' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Flickr Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Flickr link', 'azkaban-core' ),
		),
		'forrst' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Forrst Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Forrst link', 'azkaban-core' ),
		),
		'myspace' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Myspace Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Myspace link', 'azkaban-core' ),
		),
		'skype' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Skype Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom Skype link', 'azkaban-core' ),
		),
		'paypal' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'PayPal Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom paypal link', 'azkaban-core' ),
		),
		'dropbox' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Dropbox Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom dropbox link', 'azkaban-core' ),
		),
		'soundcloud' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'SoundCloud Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom soundcloud link', 'azkaban-core' ),
		),
		'vk' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'VK Link', 'azkaban-core' ),
			'desc' => __( 'Insert your custom vk link', 'azkaban-core' ),
		),
		'email' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Email Address', 'azkaban-core' ),
			'desc' => __( 'Insert an email address to display the email icon', 'azkaban-core' ),
		),
		'show_custom' => array(
			'type' => 'select',
			'label' => __( 'Show Custom Social Icon', 'azkaban-core' ),
			'desc' => __( 'Show the custom social icon specified in Theme Options', 'azkaban-core' ),
			'options' => $reverse_choices
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[social_links icons_boxed="{{iconboxed}}" icons_boxed_radius="{{iconboxedradius}}" icon_colors="{{iconcolor}}" box_colors="{{boxcolor}}" tooltip_placement="{{icontooltip}}" rss="{{rss}}" facebook="{{facebook}}" twitter="{{twitter}}" instagram="{{instagram}}" dribbble="{{dribbble}}" google="{{google}}" linkedin="{{linkedin}}" blogger="{{blogger}}" tumblr="{{tumblr}}" reddit="{{reddit}}" yahoo="{{yahoo}}" deviantart="{{deviantart}}" vimeo="{{vimeo}}" youtube="{{youtube}}" pinterest="{{pinterest}}" digg="{{digg}}" flickr="{{flickr}}" forrst="{{forrst}}" myspace="{{myspace}}" skype="{{skype}}" paypal="{{paypal}}" dropbox="{{dropbox}}" soundcloud="{{soundcloud}}" vk="{{vk}}" email="{{email}}" show_custom="{{show_custom}}" class="{{class}}" id="{{id}}"]',
	'popup_title' => __( 'Social Links Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	SoundCloud Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['soundcloud'] = array(
	'no_preview' => true,
	'params' => array(

		'url' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'SoundCloud Url', 'azkaban-core' ),
			'desc' => 'The SoundCloud url, ex: http://api.soundcloud.com/tracks/110813479'
		),
		'comments' => array(
			'type' => 'select',
			'label' => __( 'Show Comments', 'azkaban-core' ),
			'desc' => 'Choose to display comments',
			'options' => $choices
		),
		'autoplay' => array(
			'type' => 'select',
			'label' => __( 'Autoplay', 'azkaban-core' ),
			'desc' => 'Choose to autoplay the track',
			'options' => $reverse_choices
		),
		'color' => array(
			'type' => 'colorpicker',
			'std' => '#ff7700',
			'label' => __( 'Color', 'azkaban-core' ),
			'desc' => 'Select the color of the shortcode'
		),
		'width' => array(
			'std' => '100%',
			'type' => 'text',
			'label' => __( 'Width', 'azkaban-core' ),
			'desc' => 'In pixels (px) or percentage (%)'
		),
		'height' => array(
			'std' => '81px',
			'type' => 'text',
			'label' => __( 'Height', 'azkaban-core' ),
			'desc' => 'In pixels (px)'
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[soundcloud url="{{url}}" comments="{{comments}}" auto_play="{{autoplay}}" color="{{color}}" width="{{width}}" height="{{height}}" class="{{class}}" id="{{id}}"]',
	'popup_title' => __( 'Sharing Box Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Table Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['table'] = array(
	'no_preview' => true,
	'params' => array(

		'type' => array(
			'type' => 'select',
			'label' => __( 'Type', 'azkaban-core' ),
			'desc' => __( 'Select the table style', 'azkaban-core' ),
			'options' => array(
				'1' => 'Style 1',
				'2' => 'Style 2',
			)
		),
		'columns' => array(
			'type' => 'select',
			'label' => __( 'Number of Columns', 'azkaban-core' ),
			'desc' => 'Select how many columns to display',
			'options' => array(
				'1' => '1 Column',
				'2' => '2 Columns',
				'3' => '3 Columns',
				'4' => '4 Columns',
				'5' => '5 Columns'				
			)
		)
	),
	'shortcode' => '',
	'popup_title' => __( 'Table Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Tabs Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['tabs'] = array(
	'no_preview' => true,
	'params' => array(
		'layout' => array(
			'type' => 'select',
			'label' => __( 'Layout', 'azkaban-core' ),
			'desc' => __( 'Choose the layout of the shortcode', 'azkaban-core' ),
			'options' => array(
				'horizontal' => 'Horizontal',
				'vertical' => 'Vertical'
			)
		),
		'justified' => array(
			'type' => 'select',
			'label' => __( 'Justify Tabs', 'azkaban-core' ),
			'desc' => __( 'Choose to get tabs stretched over full shortcode width.', 'azkaban-core' ),
			'options' => $choices
		),		
		'backgroundcolor' => array(
			'type' => 'colorpicker',
			'std' => '',
			'label' => __( 'Background Color', 'azkaban-core' ),
			'desc' => __( 'Controls the background tab color.  Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'inactivecolor' => array(
			'type' => 'colorpicker',
			'std' => '',
			'label' => __( 'Inactive Color', 'azkaban-core' ),
			'desc' => __( 'Controls the inactive tab color. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),

	'shortcode' => '[azkaban_tabs layout="{{layout}}" justified="{{justified}}" backgroundcolor="{{backgroundcolor}}" inactivecolor="{{inactivecolor}}" class="{{class}}" id="{{id}}"]{{child_shortcode}}[/azkaban_tabs]',
	'popup_title' => __( 'Insert Tab Shortcode', 'azkaban-core' ),

	'child_shortcode' => array(
		'params' => array(
			'title' => array(
				'std' => 'Title',
				'type' => 'text',
				'label' => __( 'Tab Title', 'azkaban-core' ),
				'desc' => __( 'Title of the tab', 'azkaban-core' ),
			),
			'content' => array(
				'std' => 'Tab Content',
				'type' => 'textarea',
				'label' => __( 'Tab Content', 'azkaban-core' ),
				'desc' => __( 'Add the tabs content', 'azkaban-core' )
			)
		),
		'shortcode' => '[azkaban_tab title="{{title}}"]{{content}}[/azkaban_tab]',
		'clone_button' => __( 'Add Tab', 'azkaban-core' )
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Tagline Box Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['taglinebox'] = array(
	'no_preview' => true,
	'params' => array(
		'backgroundcolor' => array(
			'type' => 'colorpicker',
			'std' => '',
			'label' => __( 'Background Color', 'azkaban-core' ),
			'desc' => __( 'Controls the background color. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'shadow' => array(
			'type' => 'select',
			'label' => __( 'Shadow', 'azkaban-core' ),
			'desc' => __( 'Show the shadow below the box', 'azkaban-core' ),
			'options' => $reverse_choices
		),
		'shadowopacity' => array(
			'type' => 'select',
			'label' => __( 'Shadow Opacity', 'azkaban-core' ),
			'desc' => __( 'Choose the opacity of the shadow', 'azkaban-core' ),
			'options' => $dec_numbers
		),
		'border' => array(
			'std' => '1px',
			'type' => 'text',
			'label' => __( 'Border Size', 'azkaban-core' ),
			'desc' => __( 'In pixels (px), ex: 1px', 'azkaban-core' ),
		),
		'bordercolor' => array(
			'type' => 'colorpicker',
			'std' => '',
			'label' => __( 'Border Color', 'azkaban-core' ),
			'desc' => __( 'Controls the border color. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'highlightposition' => array(
			'type' => 'select',
			'label' => __( 'Highlight Border Position', 'azkaban-core' ),
			'desc' => __( 'Choose the position of the highlight. This border highlight is from theme options primary color and does not take the color from border color above', 'azkaban-core' ),
			'options' => array(
				'top' => 'Top',
				'bottom' => 'Bottom',
				'left' => 'Left',
				'right' => 'Right',
				'none' => 'None',
			)
		),
		'contentalignment' => array(
			'type' => 'select',
			'label' => __( 'Content Alignment', 'azkaban-core' ),
			'desc' => __( 'Choose how the content should be displayed.', 'azkaban-core' ),
			'options' => array(
				'left' => 'Left',
				'center' => 'Center',
				'right' => 'Right',
			)
		),		
		'button' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Button Text', 'azkaban-core' ),
			'desc' => __( 'Insert the text that will display in the button', 'azkaban-core' ),
		),
		'url' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Link', 'azkaban-core' ),
			'desc' => __( 'The url the button will link to', 'azkaban-core')
		),
		'target' => array(
			'type' => 'select',
			'label' => __( 'Link Target', 'azkaban-core' ),
			'desc' => __( '_self = open in same window <br /> _blank = open in new window', 'azkaban-core' ),
			'options' => array(
				'_self' => '_self',
				'_blank' => '_blank'
			)
		),
		'buttonsize' => array(
			'type' => 'select',
			'label' => __( 'Button Size', 'azkaban-core' ),
			'desc' => __( 'Select the button\'s size.', 'azkaban-core' ),
			'options' => array(
				'small' => 'Small',
				'medium' => 'Medium',
				'large' => 'Large',
				'xlarge' => 'XLarge',
			)
		),
		'buttontype' => array(
			'type' => 'select',
			'label' => __( 'Button Type', 'azkaban-core' ),
			'desc' => __( 'Select the button\'s type.', 'azkaban-core' ),
			'options' => array(
				'flat' => 'Flat',
				'3d' => '3D',
			)
		),
		'buttonshape' => array(
			'type' => 'select',
			'label' => __( 'Button Shape', 'azkaban-core' ),
			'desc' => __( 'Select the button\'s shape.', 'azkaban-core' ),
			'options' => array(
				'square' => 'Square',
				'pill' => 'Pill',
				'round' => 'Round',
			)
		),		
		'buttoncolor' => array(
			'type' => 'select',
			'label' => __( 'Button Color', 'azkaban-core' ),
			'desc' => __( 'Choose the button color <br />Default uses theme option selection', 'azkaban-core' ),
			'options' => array(
				'' => 'Default',
				'green' => 'Green',
				'darkgreen' => 'Dark Green',
				'orange' => 'Orange',
				'blue' => 'Blue',
				'red' => 'Red',
				'pink' => 'Pink',
				'darkgray' => 'Dark Gray',
				'lightgray' => 'Light Gray',
			)
		),
		'title' => array(
			'type' => 'textarea',
			'label' => __( 'Tagline Title', 'azkaban-core' ),
			'desc' => __( 'Insert the title text', 'azkaban-core' ),
			'std' => 'Title'
		),
		'description' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Tagline Description', 'azkaban-core' ),
			'desc' => __( 'Insert the description text', 'azkaban-core' ),
		),
		'animation_type' => array(
			'type' => 'select',
			'label' => __( 'Animation Type', 'azkaban-core' ),
			'desc' => __( 'Select the type on animation to use on the shortcode', 'azkaban-core' ),
			'options' => array(
				'0' => 'None',
				'bounce' => 'Bounce',
				'fade' => 'Fade',
				'flash' => 'Flash',
				'shake' => 'Shake',
				'slide' => 'Slide',
			)
		),
		'animation_direction' => array(
			'type' => 'select',
			'label' => __( 'Direction of Animation', 'azkaban-core' ),
			'desc' => __( 'Select the incoming direction for the animation', 'azkaban-core' ),
			'options' => array(
				'down' => 'Down',
				'left' => 'Left',
				'right' => 'Right',
				'up' => 'Up',
			)
		),
		'animation_speed' => array(
			'type' => 'select',
			'std' => '',
			'label' => __( 'Speed of Animation', 'azkaban-core' ),
			'desc' => __( 'Type in speed of animation in seconds (0.1 - 1)', 'azkaban-core' ),
			'options' => $dec_numbers,
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[tagline_box backgroundcolor="{{backgroundcolor}}" shadow="{{shadow}}" shadowopacity="{{shadowopacity}}" border="{{border}}" bordercolor="{{bordercolor}}" highlightposition="{{highlightposition}}" content_alignment="{{contentalignment}}" link="{{url}}" linktarget="{{target}}" button_size="{{buttonsize}}" button_shape="{{buttonshape}}" button_type="{{buttontype}}" buttoncolor="{{buttoncolor}}" button="{{button}}" title="{{title}}" description="{{description}}" animation_type="{{animation_type}}" animation_direction="{{animation_direction}}" animation_speed="{{animation_speed}}" class="{{class}}" id="{{id}}"][/tagline_box]',
	'popup_title' => __( 'Insert Tagline Box Shortcode', 'azkaban-core')
);

/*-----------------------------------------------------------------------------------*/
/*	Testimonials Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['testimonials'] = array(
	'no_preview' => true,
	'params' => array(
		'backgroundcolor' => array(
			'type' => 'colorpicker',
			'std' => '',
			'label' => __( 'Background Color', 'azkaban-core' ),
			'desc' => __( 'Controls the background color.  Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'textcolor' => array(
			'type' => 'colorpicker',
			'std' => '',
			'label' => __( 'Text Color', 'azkaban-core' ),
			'desc' => __( 'Controls the text color. Leave blank for theme option selection.', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),		
	),
	'shortcode' => '[testimonials backgroundcolor="{{backgroundcolor}}" textcolor="{{textcolor}}" class="{{class}}" id="{{id}}"]{{child_shortcode}}[/testimonials]',
	'popup_title' => __( 'Insert Testimonials Shortcode', 'azkaban-core' ),

	'child_shortcode' => array(
		'params' => array(
			'name' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Name', 'azkaban-core' ),
				'desc' => __( 'Insert the name of the person.', 'azkaban-core' ),
			),
			'avatar' => array(
				'type' => 'select',
				'label' => __( 'Avatar', 'azkaban-core' ),
				'desc' => __( 'Choose which kind of Avatar to be displayed.', 'azkaban-core' ),
				'options' => array(
					'male' => 'Male',
					'female' => 'Female',
					'image' => 'Image',
					'none' => 'None'
				)
			),
			'image' => array(
				'type' => 'uploader',
				'label' => __( 'Custom Avatar', 'azkaban-core' ),
				'desc' => __( 'Upload a custom avatar image.', 'azkaban-core' ),
			),			
			'company' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Company', 'azkaban-core' ),
				'desc' => __( 'Insert the name of the company.', 'azkaban-core' ),
			),
			'link' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Link', 'azkaban-core' ),
				'desc' => __( 'Add the url the company name will link to.', 'azkaban-core' ),
			),
			'target' => array(
				'type' => 'select',
				'label' => __( 'Target', 'azkaban-core' ),
				'desc' => __( '_self = open in same window <br />_blank = open in new window.', 'azkaban-core' ),
				'options' => array(
					'_self' => '_self',
					'_blank' => '_blank'
				)
			),
			'content' => array(
				'std' => '',
				'type' => 'textarea',
				'label' => __( 'Testimonial Content', 'azkaban-core' ),
				'desc' => __( 'Add the testimonial content', 'azkaban-core' ),
			)
		),
		'shortcode' => '[testimonial name="{{name}}" avatar="{{avatar}}" image="{{image}}" company="{{company}}" link="{{link}}" target="{{target}}"]{{content}}[/testimonial]',
		'clone_button' => __( 'Add Testimonial', 'azkaban-core' )
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Title Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['title'] = array(
	'no_preview' => true,
	'params' => array(
		'size' => array(
			'type' => 'select',
			'label' => __( 'Title Size', 'azkaban-core' ),
			'desc' => __( 'Choose the title size, H1-H6', 'azkaban-core' ),
			'options' => azkaban_shortcodes_range( 6, false )
		),
		'contentalign' => array(
			'type' => 'select',
			'label' => __( 'Title Alignment', 'azkaban-core' ),
			'desc' => __( 'Choose to align the heading left or right.', 'azkaban-core' ),
			'options' => array(
				'left' => 'Left',
				'right' => 'Right'
			)
		),
		'separator' => array(
			'type' => 'select',
			'label' => __( 'Separator', 'azkaban-core' ),
			'desc' => __( 'Choose the kind of the title separator you want to use.', 'azkaban-core' ),
			'options' => array(
				'single' => 'Single',
				'double' => 'Double',
				'underline' => 'Underline',			
			)
		),			
		'sepstyle' => array(
			'type' => 'select',
			'label' => __( 'Separator Style', 'azkaban-core' ),
			'desc' => __( 'Choose the style of the title separator.', 'azkaban-core' ),
			'options' => array(
				'solid' => 'Solid',
				'dashed' => 'Dashed',
				'dotted' => 'Dotted',			
			)
		),		
		'sepcolor' => array(
			'type' => 'colorpicker',
			'label' => __( 'Separator Color', 'azkaban-core' ),
			'desc' => __( 'Controls the separator color.  Leave blank for theme option selection.', 'azkaban-core')
		),		
		'content' => array(
			'std' => '',
			'type' => 'textarea',
			'label' => __( 'Title', 'azkaban-core' ),
			'desc' => __( 'Insert the title text', 'azkaban-core' ),
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),			
	),
	'shortcode' => '[title size="{{size}}" content_align="{{contentalign}}" style_type="{{separator}} {{sepstyle}}" sep_color="{{sepcolor}}" class="{{class}}" id="{{id}}"]{{content}}[/title]',
	'popup_title' => __( 'Sharing Box Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Toggles Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['toggles'] = array(
	'no_preview' => true,
	'params' => array(
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),
		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS ID', 'azkaban-core' ),
			'desc' => __( 'Add an ID to the wrapping HTML element.', 'azkaban-core' )
		),	
	),
	'shortcode' => '[accordian class="{{class}}" id="{{id}}"]{{child_shortcode}}[/accordian]',
	'popup_title' => __( 'Insert Toggles Shortcode', 'azkaban-core' ),

	'child_shortcode' => array(
		'params' => array(
			'title' => array(
				'std' => '',
				'type' => 'text',
				'label' => __( 'Title', 'azkaban-core' ),
				'desc' => __( 'Insert the toggle title', 'azkaban-core' ),
			),
			'open' => array(
				'type' => 'select',
				'label' => __( 'Open by Default', 'azkaban-core' ),
				'desc' => __( 'Choose to have the toggle open when page loads', 'azkaban-core' ),
				'options' => $reverse_choices
			),
			'content' => array(
				'std' => '',
				'type' => 'textarea',
				'label' => __( 'Toggle Content', 'azkaban-core' ),
				'desc' => __( 'Insert the toggle content', 'azkaban-core' ),
			)
		),
		'shortcode' => '[toggle title="{{title}}" open="{{open}}"]{{content}}[/toggle]',
		'clone_button' => __( 'Add Toggle', 'azkaban-core')
	)
);

/*-----------------------------------------------------------------------------------*/
/*	Vimeo Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['vimeo'] = array(
	'no_preview' => true,
	'params' => array(

		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Video ID', 'azkaban-core' ),
			'desc' => __( 'For example the Video ID for <br />https://vimeo.com/75230326 is 75230326', 'azkaban-core' )
		),
		'width' => array(
			'std' => '600',
			'type' => 'text',
			'label' => __( 'Width', 'azkaban-core' ),
			'desc' => __( 'In pixels but only enter a number, ex: 600', 'azkaban-core' )
		),
		'height' => array(
			'std' => '350',
			'type' => 'text',
			'label' => __( 'Height', 'azkaban-core' ),
			'desc' => __( 'In pixels but enter a number, ex: 350', 'azkaban-core' )
		),
		'autoplay' => array(
			'type' => 'select',
			'label' => __( 'Autoplay Video', 'azkaban-core' ),
			'desc' =>  __( 'Set to yes to make video autoplaying', 'azkaban-core' ),
			'options' => $reverse_choices
		),
		'apiparams' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'AdditionalAPI Parameter', 'azkaban-core' ),
			'desc' => __( 'Use additional API parameter, for example &title=0 to disable title on video. VimeoPlus account may be required.', 'azkaban-core' )
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),		
	),
	'shortcode' => '[vimeo id="{{id}}" width="{{width}}" height="{{height}}" autoplay="{{autoplay}}" api_params="{{apiparams}}" class="{{class}}"]',
	'popup_title' => __( 'Vimeo Shortcode', 'azkaban-core' )
);

/*-----------------------------------------------------------------------------------*/
/*	Youtube Config
/*-----------------------------------------------------------------------------------*/
$azkaban_shortcodes['youtube'] = array(
	'no_preview' => true,
	'params' => array(

		'id' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'Video ID', 'azkaban-core' ),
			'desc' => 'For example the Video ID for <br />http://www.youtube.com/LOfeCR7KqUs is LOfeCR7KqUs'
		),
		'width' => array(
			'std' => '600',
			'type' => 'text',
			'label' => __( 'Width', 'azkaban-core' ),
			'desc' => 'In pixels but only enter a number, ex: 600'
		),
		'height' => array(
			'std' => '350',
			'type' => 'text',
			'label' => __( 'Height', 'azkaban-core' ),
			'desc' => 'In pixels but only enter a number, ex: 350'
		),
		'autoplay' => array(
			'type' => 'select',
			'label' => __( 'Autoplay Video', 'azkaban-core' ),
			'desc' =>  __( 'Set to yes to make video autoplaying', 'azkaban-core' ),
			'options' => $reverse_choices
		),
		'apiparams' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'AdditionalAPI Parameter', 'azkaban-core' ),
			'desc' => 'Use additional API parameter, for example &rel=0 to disable related videos'
		),
		'class' => array(
			'std' => '',
			'type' => 'text',
			'label' => __( 'CSS Class', 'azkaban-core' ),
			'desc' => __( 'Add a class to the wrapping HTML element.', 'azkaban-core' )
		),		
	),
	'shortcode' => '[youtube id="{{id}}" width="{{width}}" height="{{height}}" autoplay="{{autoplay}}" api_params="{{apiparams}}" class="{{class}}"]',
	'popup_title' => __( 'Youtube Shortcode', 'azkaban-core' )
);
