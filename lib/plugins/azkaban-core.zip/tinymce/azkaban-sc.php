<?php

// loads the shortcodes class, wordpress is loaded with it
require_once( 'shortcodes.class.php' );

// get popup type
$popup = trim( $_GET['popup'] );
$shortcode = new azkaban_shortcodes( $popup );

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>
<div id="azkaban-popup">

	<div id="azkaban-shortcode-wrap">

		<div id="azkaban-sc-form-wrap">

			<?php
			$select_shortcode = array(
					'select' => 'Choose a Shortcode',
					'alert' => 'Alert',
					'blog' => 'Blog',
					'button' => 'Button',
					'checklist' => 'Checklist',
					'clientslider' => 'Client Slider',
					'columns' => 'Columns',
					'contentboxes' => 'Content Boxes',
					'countersbox' => 'Counters Box',					
					'counterscircle' => 'Counters Circle',
					'dropcap' => 'Dropcap',
					'fontawesome' => 'Font Awesome',
					'fullwidth' => 'Full Width Container',
					'highlight' => 'Highlight',
					'person' => 'Person',
					'postslider' => 'Post Slider',
					'progressbar' => 'Progress Bar',
					'recentposts' => 'Recent Posts',
					'recentworks' => 'Recent Works',
					'sectionseparator' => 'Section Separator',
					'separator' => 'Separator',
					'sharingbox' => 'Sharing Box',
					'sociallinks' => 'Social Links',
					'soundcloud' => 'SoundCloud',
					'table' => 'Table',
					'tabs' => 'Tabs',
					'taglinebox' => 'Tagline Box',
					'testimonials' => 'Testimonials',
					'title' => 'Title',
					'toggles' => 'Toggles',
					'vimeo' => 'Vimeo',
					'youtube' => 'Youtube'
			);
			?>
			<table id="azkaban-sc-form-table" class="azkaban-shortcode-selector">
				<tbody>
					<tr class="form-row">
						<td class="label">Choose Shortcode</td>
						<td class="field">
							<div class="azkaban-form-select-field">
							<div class="azkaban-shortcodes-arrow">&#xf107;</div>
								<select name="azkaban_select_shortcode" id="azkaban_select_shortcode" class="azkaban-form-select azkaban-input">
									<?php foreach($select_shortcode as $shortcode_key => $shortcode_value): ?>
									<?php if($shortcode_key == $popup): $selected = 'selected="selected"'; else: $selected = ''; endif; ?>
									<option value="<?php echo $shortcode_key; ?>" <?php echo $selected; ?>><?php echo $shortcode_value; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
			<form method="post" id="azkaban-sc-form">

				<table id="azkaban-sc-form-table">

					<?php echo $shortcode->output; ?>

					<tbody class="azkaban-sc-form-button">
						<tr class="form-row">
							<td class="field"><a href="#" class="azkaban-insert">Insert Shortcode</a></td>
						</tr>
					</tbody>

				</table>
				<!-- /#azkaban-sc-form-table -->

			</form>
			<!-- /#azkaban-sc-form -->

		</div>
		<!-- /#azkaban-sc-form-wrap -->

		<div class="clear"></div>

	</div>
	<!-- /#azkaban-shortcode-wrap -->

</div>
<!-- /#azkaban-popup -->

</body>
</html>