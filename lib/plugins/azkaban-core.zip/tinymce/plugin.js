tinymce.PluginManager.add('azkaban_button', function(ed, url) {
    ed.addCommand("azkabanPopup", function ( a, params )
    {
        
        var popup = 'shortcode-generator';

        if(typeof params != 'undefined' && params.identifier) {
            popup = params.identifier;
        }

        // load thickbox
        tb_show("Azkaban Shortcodes", ajaxurl + "?action=azkaban_shortcodes_popup&popup=" + popup + "&width=" + 800);

        jQuery('#TB_window').hide();
    });

    // Add a button that opens a window
    ed.addButton('azkaban_button', {
        text: '',
        icon: true,
        image: AzkabanShortcodes.plugin_folder + '/tinymce/images/icon.png',
        cmd: 'azkabanPopup'
    });
});