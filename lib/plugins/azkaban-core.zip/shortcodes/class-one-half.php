<?php
class AX_OneHalf {

	public static $args;

	/**
	 * Initiate the shortcode
	 */
	public function __construct() {

		add_filter( 'azkaban_attr_one-half-shortcode', array( $this, 'attr' ) );
		add_shortcode( 'one_half', array( $this, 'render' ) );

	}

	/**
	 * Render the shortcode
	 *
	 * @param  array $args     Shortcode paramters
	 * @param  string $content Content between shortcode
	 * @return string          HTML output
	 */
	function render( $args, $content = '') {

		$defaults =	shortcode_atts(
			array(
				'class'	=> '',
				'id'	=> '',
				'last'  => 'no'
			), $args
		);

		extract( $defaults );

		self::$args = $defaults;

		$clearfix = '';
		if( self::$args['last'] == 'yes' ) {
			$clearfix = sprintf( '<div %s></div>', AzkabanCore_Plugin::attributes( 'az-clearfix' ) );
		}

		$html = sprintf( '<div %s>%s</div>%s', AzkabanCore_Plugin::attributes( 'one-half-shortcode' ), do_shortcode( $content ), $clearfix );

		return $html;

	}

	function attr() {

		$attr['class'] = 'az-one-half one_half az-column';

		if( self::$args['last'] == 'yes' ) {
			$attr['class'] .= ' last';
		}

		if( self::$args['class'] ) {
			$attr['class'] .= ' ' . self::$args['class'];
		}

		if( self::$args['id'] ) {
			$attr['id'] = self::$args['id'];
		}

		return $attr;

	}

}

new AX_OneHalf();